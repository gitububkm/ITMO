"""
Управление подключениями к PostgreSQL
Создание сессий для разных ролей
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from typing import Dict, Optional
import config

Base = declarative_base()

# Хранилище подключений для разных ролей
_engines: Dict[str, any] = {}
_session_makers: Dict[str, sessionmaker] = {}


def get_engine(role: str = "root"):
    """
    Получить engine для указанной роли PostgreSQL
    
    Args:
        role: роль PostgreSQL (root, mechanic, logistic, rental_manager, admin)
    
    Returns:
        SQLAlchemy Engine
    """
    if role not in _engines:
        conn_string = config.DatabaseConfig.get_connection_string(role)
        _engines[role] = create_engine(
            conn_string,
            pool_pre_ping=True,  # Проверка подключения перед использованием
            echo=False  # Логирование SQL (можно включить для отладки)
        )
    return _engines[role]


def get_session(role: str = "root"):
    """
    Получить сессию SQLAlchemy для указанной роли
    
    Args:
        role: роль PostgreSQL (root, mechanic, logistic, rental_manager, admin)
    
    Returns:
        SQLAlchemy Session
    """
    if role not in _session_makers:
        engine = get_engine(role)
        _session_makers[role] = sessionmaker(bind=engine, autocommit=False, autoflush=False)
    
    SessionLocal = _session_makers[role]
    return SessionLocal()


def get_session_for_role(role: str):
    """
    Получить сессию для конкретной роли PostgreSQL
    Используется для демонстрации разграничения доступа
    
    Args:
        role: роль PostgreSQL (mechanic, logistic, rental_manager, admin)
    
    Returns:
        SQLAlchemy Session
    """
    if role not in ["mechanic", "logistic", "rental_manager", "admin"]:
        raise ValueError(f"Invalid role: {role}. Must be one of: mechanic, logistic, rental_manager, admin")
    
    return get_session(role)


def close_all_connections():
    """Закрыть все подключения"""
    for engine in _engines.values():
        engine.dispose()
    _engines.clear()
    _session_makers.clear()

