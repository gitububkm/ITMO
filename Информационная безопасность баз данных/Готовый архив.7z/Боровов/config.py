"""
Конфигурация приложения
Настройки подключения к БД, ролей и безопасности
"""
import os
from typing import Dict
from pydantic_settings import BaseSettings
from dotenv import load_dotenv

load_dotenv()


class DatabaseConfig:
    """Конфигурация подключения к PostgreSQL"""
    
    # Базовые настройки
    HOST: str = os.getenv("DB_HOST", "localhost")
    PORT: int = int(os.getenv("DB_PORT", "5432"))
    NAME: str = os.getenv("DB_NAME", "construction_equipment_db")
    
    # Суперпользователь (для создания таблиц, миграций)
    USER_ROOT: str = os.getenv("DB_USER_ROOT", "postgres")
    PASS_ROOT: str = os.getenv("DB_PASS_ROOT", "postgres")
    
    # Роли PostgreSQL для разграничения доступа
    ROLES: Dict[str, Dict[str, str]] = {
        "mechanic": {
            "user": os.getenv("DB_USER_MECHANIC", "mechanic"),
            "password": os.getenv("DB_PASS_MECHANIC", "mechanic_pass")
        },
        "logistic": {
            "user": os.getenv("DB_USER_LOGISTIC", "logistic"),
            "password": os.getenv("DB_PASS_LOGISTIC", "logistic_pass")
        },
        "rental_manager": {
            "user": os.getenv("DB_USER_RENTAL_MANAGER", "rental_manager"),
            "password": os.getenv("DB_PASS_RENTAL_MANAGER", "rental_pass")
        },
        "admin": {
            "user": os.getenv("DB_USER_ADMIN", "admin2_role"),
            "password": os.getenv("DB_PASS_ADMIN", "admin2_pass")
        }
    }
    
    @classmethod
    def get_connection_string(cls, role: str = "root") -> str:
        """
        Возвращает строку подключения к БД для указанной роли
        
        Args:
            role: роль PostgreSQL (root, mechanic, logistic, rental_manager, admin)
        
        Returns:
            строка подключения в формате PostgreSQL
        """
        if role == "root":
            user = cls.USER_ROOT
            password = cls.PASS_ROOT
        elif role in cls.ROLES:
            user = cls.ROLES[role]["user"]
            password = cls.ROLES[role]["password"]
        else:
            raise ValueError(f"Unknown role: {role}")
        
        return f"postgresql://{user}:{password}@{cls.HOST}:{cls.PORT}/{cls.NAME}"


class AppSettings(BaseSettings):
    """Настройки приложения"""
    
    SECRET_KEY: str = os.getenv("SECRET_KEY", "your-secret-key-change-in-production")
    ALGORITHM: str = os.getenv("ALGORITHM", "HS256")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "30"))
    
    APP_HOST: str = os.getenv("APP_HOST", "127.0.0.1")
    APP_PORT: int = int(os.getenv("APP_PORT", "8000"))
    
    class Config:
        env_file = ".env"


# Экземпляр настроек
settings = AppSettings()

