"""
Демонстрация CRUD операций и работы с разными ролями PostgreSQL
Показывает:
- SELECT операции от разных ролей
- INSERT операции (с логированием в таблицу logs)
- UPDATE операции (с логированием)
- Ошибки доступа (permission denied)
"""
from db.database import get_session_for_role
from utils.crud import (
    get_equipment_list, create_equipment, update_equipment_status,
    get_rentals_list, create_rental, get_movements_list,
    get_service_logs_list, get_logs_list,
    PermissionDeniedError, execute_with_role_check
)
from models.db_models import Log
from datetime import date, datetime

def demo_select(role: str):
    """Демонстрация SELECT операций"""
    print(f"\n{'='*60}")
    print(f"ДЕМОНСТРАЦИЯ SELECT - роль: {role}")
    print(f"{'='*60}")
    
    try:
        # Оборудование
        equipment = execute_with_role_check(role, "Просмотр оборудования", get_equipment_list, role)
        print(f"✅ Оборудование: {len(equipment)} записей")
        
        # Аренда
        try:
            rentals = execute_with_role_check(role, "Просмотр аренды", get_rentals_list, role)
            print(f"✅ Аренда: {len(rentals)} записей")
        except PermissionDeniedError as e:
            print(f"❌ Аренда: {str(e)[:80]}...")
        
        # Перемещения
        try:
            movements = execute_with_role_check(role, "Просмотр перемещений", get_movements_list, role)
            print(f"✅ Перемещения: {len(movements)} записей")
        except PermissionDeniedError as e:
            print(f"❌ Перемещения: {str(e)[:80]}...")
        
        # ТО/ремонты
        try:
            service_logs = execute_with_role_check(role, "Просмотр ТО/ремонтов", get_service_logs_list, role)
            print(f"✅ ТО/ремонты: {len(service_logs)} записей")
        except PermissionDeniedError as e:
            print(f"❌ ТО/ремонты: {str(e)[:80]}...")
        
        # Логи (только для admin)
        if role == "admin":
            try:
                logs = execute_with_role_check(role, "Просмотр логов", get_logs_list, role, limit=5)
                print(f"✅ Логи: {len(logs)} последних записей")
            except PermissionDeniedError as e:
                print(f"❌ Логи: {str(e)[:80]}...")
        
    except PermissionDeniedError as e:
        print(f"❌ Permission Denied: {str(e)}")
    except Exception as e:
        print(f"❌ Ошибка: {str(e)}")


def demo_insert(role: str):
    """Демонстрация INSERT операций (должны логироваться триггерами)"""
    print(f"\n{'='*60}")
    print(f"ДЕМОНСТРАЦИЯ INSERT - роль: {role}")
    print(f"{'='*60}")
    
    try:
        # Создание оборудования
        if role in ["admin", "rental_manager"]:
            print("\n1. Создание нового оборудования:")
            try:
                new_eq = execute_with_role_check(
                    role, "Создание оборудования", create_equipment,
                    role, f"Тестовый экскаватор {datetime.now().strftime('%H%M%S')}",
                    "EXC-2024", None, None
                )
                print(f"   ✅ Оборудование создано: ID={new_eq['id']}, название='{new_eq['name']}'")
                print(f"   📝 Действие должно быть залогировано в таблицу logs")
                
                # Проверка логов
                db = get_session_for_role(role)
                try:
                    recent_logs = db.query(Log).filter(
                        Log.table_name == "equipment",
                        Log.record_id == new_eq['id']
                    ).order_by(Log.created_at.desc()).limit(1).all()
                    
                    if recent_logs:
                        log = recent_logs[0]
                        print(f"   ✅ Лог найден: action={log.action}, created_at={log.created_at}")
                    else:
                        print(f"   ⚠️  Лог не найден (возможно, триггер не настроен)")
                finally:
                    db.close()
                    
            except PermissionDeniedError as e:
                print(f"   ❌ Permission Denied: {str(e)[:80]}...")
            except Exception as e:
                print(f"   ❌ Ошибка: {str(e)}")
        else:
            print("\n⚠️  Эта роль не имеет прав на создание оборудования")
        
    except Exception as e:
        print(f"❌ Общая ошибка: {str(e)}")


def demo_update(role: str):
    """Демонстрация UPDATE операций (должны логироваться триггерами)"""
    print(f"\n{'='*60}")
    print(f"ДЕМОНСТРАЦИЯ UPDATE - роль: {role}")
    print(f"{'='*60}")
    
    try:
        # Обновление статуса оборудования
        if role in ["admin", "rental_manager"]:
            print("\n1. Обновление статуса оборудования:")
            try:
                # Получаем первое оборудование
                equipment_list = execute_with_role_check(role, "Просмотр оборудования", get_equipment_list, role)
                
                if equipment_list:
                    eq_id = equipment_list[0]["id"]
                    old_status = equipment_list[0]["status"]
                    
                    new_status = "maintenance" if old_status != "maintenance" else "available"
                    
                    updated = execute_with_role_check(
                        role, "Обновление статуса оборудования", update_equipment_status,
                        role, eq_id, new_status
                    )
                    print(f"   ✅ Статус обновлён: ID={updated['id']}, новый статус='{updated['status']}'")
                    print(f"   📝 Действие должно быть залогировано в таблицу logs")
                else:
                    print(f"   ⚠️  Нет оборудования для обновления")
                    
            except PermissionDeniedError as e:
                print(f"   ❌ Permission Denied: {str(e)[:80]}...")
            except Exception as e:
                print(f"   ❌ Ошибка: {str(e)}")
        else:
            print("\n⚠️  Эта роль не имеет прав на обновление оборудования")
        
    except Exception as e:
        print(f"❌ Общая ошибка: {str(e)}")


def demo_permission_denied():
    """Демонстрация ошибок доступа"""
    print(f"\n{'='*60}")
    print("ДЕМОНСТРАЦИЯ ОШИБОК ДОСТУПА (PERMISSION DENIED)")
    print(f"{'='*60}")
    
    # Механик пытается прочитать аренду
    print("\n1. Механик пытается прочитать аренду:")
    try:
        rentals = execute_with_role_check("mechanic", "Просмотр аренды", get_rentals_list, "mechanic")
        print(f"   ⚠️  Неожиданно: доступ разрешён ({len(rentals)} записей)")
    except PermissionDeniedError as e:
        print(f"   ✅ Permission Denied - как и ожидалось!")
        print(f"   📝 Ошибка: {str(e)[:100]}...")
    except Exception as e:
        print(f"   ❌ Другая ошибка: {str(e)}")
    
    # Логист пытается создать аренду
    print("\n2. Логист пытается создать аренду:")
    try:
        from datetime import date
        new_rental = execute_with_role_check(
            "logistic", "Создание аренды", create_rental,
            "logistic", 1, 1, date.today(), 5000.0
        )
        print(f"   ⚠️  Неожиданно: доступ разрешён")
    except PermissionDeniedError as e:
        print(f"   ✅ Permission Denied - как и ожидалось!")
        print(f"   📝 Ошибка: {str(e)[:100]}...")
    except Exception as e:
        print(f"   ❌ Другая ошибка: {str(e)}")


def main():
    """Запуск всех демонстраций"""
    print("\n" + "="*60)
    print("ДЕМОНСТРАЦИЯ CRUD ОПЕРАЦИЙ И РАЗГРАНИЧЕНИЯ ДОСТУПА")
    print("="*60)
    
    roles = ["mechanic", "logistic", "rental_manager", "admin"]
    
    # SELECT для всех ролей
    for role in roles:
        demo_select(role)
    
    # INSERT демонстрация
    demo_insert("rental_manager")
    demo_insert("admin")
    
    # UPDATE демонстрация
    demo_update("rental_manager")
    
    # Демонстрация ошибок доступа
    demo_permission_denied()
    
    print("\n" + "="*60)
    print("ДЕМОНСТРАЦИЯ ЗАВЕРШЕНА")
    print("="*60)


if __name__ == "__main__":
    main()

