"""
Скрипт для тестирования подключения к PostgreSQL
Проверяет подключение от разных ролей
"""
import sys
from db.database import get_session, get_engine
from models.db_models import Equipment, Rental, Movement, ServiceLog, Log
from config import DatabaseConfig

def test_connection(role: str = "root"):
    """Тестировать подключение к БД от указанной роли"""
    print(f"\n{'='*60}")
    print(f"Тестирование подключения для роли: {role}")
    print(f"{'='*60}")
    
    try:
        # Проверка подключения
        engine = get_engine(role)
        with engine.connect() as conn:
            result = conn.execute("SELECT version();")
            version = result.fetchone()[0]
            print(f"✅ Подключение успешно!")
            print(f"📊 PostgreSQL версия: {version[:50]}...")
        
        # Попытка выполнить SELECT
        db = get_session(role)
        try:
            equipment_count = db.query(Equipment).count()
            print(f"✅ SELECT: найдено {equipment_count} записей в таблице equipment")
            
            rentals_count = db.query(Rental).count()
            print(f"✅ SELECT: найдено {rentals_count} записей в таблице rentals")
            
            movements_count = db.query(Movement).count()
            print(f"✅ SELECT: найдено {movements_count} записей в таблице movements")
            
            logs_count = db.query(Log).count()
            print(f"✅ SELECT: найдено {logs_count} записей в таблице logs")
            
        except Exception as e:
            print(f"⚠️  Ошибка при выполнении SELECT: {str(e)}")
            if "permission denied" in str(e).lower() or "доступ запрещён" in str(e).lower():
                print("   ❌ Permission Denied - роль не имеет прав на чтение")
        finally:
            db.close()
            
    except Exception as e:
        print(f"❌ Ошибка подключения: {str(e)}")
        return False
    
    return True


def test_all_roles():
    """Тестировать подключение от всех ролей"""
    print("\n" + "="*60)
    print("ТЕСТИРОВАНИЕ ПОДКЛЮЧЕНИЙ К POSTGRESQL")
    print("="*60)
    
    roles = ["root", "mechanic", "logistic", "rental_manager", "admin"]
    
    results = {}
    for role in roles:
        try:
            results[role] = test_connection(role)
        except Exception as e:
            print(f"❌ Критическая ошибка для роли {role}: {str(e)}")
            results[role] = False
    
    # Итоги
    print("\n" + "="*60)
    print("ИТОГИ ТЕСТИРОВАНИЯ")
    print("="*60)
    for role, success in results.items():
        status = "✅ Успешно" if success else "❌ Ошибка"
        print(f"{role:20s} - {status}")


def test_permission_denied():
    """
    Демонстрация ошибок доступа (permission denied)
    Показывает, как разные роли получают ошибки при попытке доступа к запрещённым ресурсам
    """
    print("\n" + "="*60)
    print("ДЕМОНСТРАЦИЯ ОШИБОК ДОСТУПА (PERMISSION DENIED)")
    print("="*60)
    
    # Попытка механика прочитать аренду (должен быть запрет)
    print("\n1. Механик пытается прочитать аренду (rentals):")
    try:
        db = get_session("mechanic")
        try:
            rentals = db.query(Rental).all()
            print(f"   ⚠️  Неожиданно: доступ разрешён ({len(rentals)} записей)")
        except Exception as e:
            if "permission denied" in str(e).lower() or "доступ запрещён" in str(e).lower():
                print(f"   ✅ Permission Denied - как и ожидалось!")
                print(f"   📝 Ошибка: {str(e)[:100]}...")
            else:
                print(f"   ❌ Другая ошибка: {str(e)}")
        finally:
            db.close()
    except Exception as e:
        print(f"   ❌ Ошибка подключения: {str(e)}")
    
    # Попытка логиста прочитать статистику (если такая таблица есть и доступ запрещён)
    print("\n2. Логист пытается прочитать ТО/ремонты (service_logs):")
    try:
        db = get_session("logistic")
        try:
            logs = db.query(ServiceLog).all()
            print(f"   ✅ Доступ разрешён ({len(logs)} записей)")
        except Exception as e:
            if "permission denied" in str(e).lower() or "доступ запрещён" in str(e).lower():
                print(f"   ✅ Permission Denied - как и ожидалось!")
                print(f"   📝 Ошибка: {str(e)[:100]}...")
            else:
                print(f"   ❌ Другая ошибка: {str(e)}")
        finally:
            db.close()
    except Exception as e:
        print(f"   ❌ Ошибка подключения: {str(e)}")


if __name__ == "__main__":
    if len(sys.argv) > 1:
        role = sys.argv[1]
        test_connection(role)
    else:
        test_all_roles()
        test_permission_denied()

