"""
CRUD операции для работы с БД
Используют подключения от имени разных ролей PostgreSQL
Демонстрируют разграничение доступа
"""
from sqlalchemy.exc import ProgrammingError, OperationalError
from typing import List, Optional, Dict, Any
from datetime import datetime, date
from db.database import get_session_for_role
from models.db_models import (
    Equipment, Location, Rental, ServiceLog, Movement,
    Counterparty, Log, User, Statistics
)
from models.db_models import EquipmentStatus, RentalStatus, ServiceType, LocationType, WorkStatus


class PermissionDeniedError(Exception):
    """Ошибка доступа (permission denied от PostgreSQL)"""
    pass


def execute_with_role_check(role: str, operation_name: str, func, *args, **kwargs):
    """
    Выполнить операцию с проверкой прав доступа
    
    Args:
        role: роль PostgreSQL
        operation_name: название операции (для сообщений)
        func: функция для выполнения
        *args, **kwargs: аргументы функции
    
    Returns:
        результат выполнения функции
    
    Raises:
        PermissionDeniedError: если доступ запрещён
    """
    try:
        return func(role, *args, **kwargs)
    except (ProgrammingError, OperationalError) as e:
        if "permission denied" in str(e).lower() or "доступ запрещён" in str(e).lower():
            raise PermissionDeniedError(f"Роль '{role}' не имеет прав для операции '{operation_name}': {str(e)}")
        raise


# ========== EQUIPMENT (Оборудование) ==========

def get_equipment_list(role: str) -> List[Dict[str, Any]]:
    """Получить список оборудования"""
    db = get_session_for_role(role)
    try:
        equipment_list = db.query(Equipment).all()
        return [
            {
                "id": eq.id,
                "name": eq.name,
                "model": eq.model,
                "serial_number": eq.serial_number,
                "status": eq.status.value if eq.status else None,
                "current_location_id": eq.current_location_id,
                "purchase_date": str(eq.purchase_date) if eq.purchase_date else None,
                "price": float(eq.price) if eq.price else None
            }
            for eq in equipment_list
        ]
    finally:
        db.close()


def create_equipment(role: str, name: str, model: Optional[str] = None, 
                     serial_number: Optional[str] = None, location_id: Optional[int] = None) -> Dict[str, Any]:
    """Создать новое оборудование (должно логироваться триггером)"""
    db = get_session_for_role(role)
    try:
        new_equipment = Equipment(
            name=name,
            model=model,
            serial_number=serial_number,
            status=EquipmentStatus.available,
            current_location_id=location_id
        )
        db.add(new_equipment)
        db.commit()
        db.refresh(new_equipment)
        
        return {
            "id": new_equipment.id,
            "name": new_equipment.name,
            "model": new_equipment.model,
            "serial_number": new_equipment.serial_number,
            "status": new_equipment.status.value
        }
    except Exception as e:
        db.rollback()
        raise
    finally:
        db.close()


def update_equipment_status(role: str, equipment_id: int, new_status: str) -> Dict[str, Any]:
    """Обновить статус оборудования"""
    db = get_session_for_role(role)
    try:
        equipment = db.query(Equipment).filter(Equipment.id == equipment_id).first()
        if not equipment:
            raise ValueError(f"Оборудование с ID {equipment_id} не найдено")
        
        equipment.status = EquipmentStatus(new_status)
        db.commit()
        db.refresh(equipment)
        
        return {
            "id": equipment.id,
            "name": equipment.name,
            "status": equipment.status.value
        }
    except Exception as e:
        db.rollback()
        raise
    finally:
        db.close()


# ========== RENTALS (Аренда) ==========

def get_rentals_list(role: str) -> List[Dict[str, Any]]:
    """Получить список аренды"""
    db = get_session_for_role(role)
    try:
        rentals_list = db.query(Rental).all()
        return [
            {
                "id": r.id,
                "equipment_id": r.equipment_id,
                "counterparty_id": r.counterparty_id,
                "start_date": str(r.start_date),
                "end_date": str(r.end_date) if r.end_date else None,
                "daily_rate": float(r.daily_rate) if r.daily_rate else None,
                "status": r.status.value if r.status else None
            }
            for r in rentals_list
        ]
    finally:
        db.close()


def create_rental(role: str, equipment_id: int, counterparty_id: int,
                  start_date: date, daily_rate: float, end_date: Optional[date] = None) -> Dict[str, Any]:
    """Создать новую аренду (должно логироваться триггером)"""
    db = get_session_for_role(role)
    try:
        new_rental = Rental(
            equipment_id=equipment_id,
            counterparty_id=counterparty_id,
            start_date=start_date,
            end_date=end_date,
            daily_rate=daily_rate,
            status=RentalStatus.active
        )
        db.add(new_rental)
        db.commit()
        db.refresh(new_rental)
        
        return {
            "id": new_rental.id,
            "equipment_id": new_rental.equipment_id,
            "counterparty_id": new_rental.counterparty_id,
            "status": new_rental.status.value
        }
    except Exception as e:
        db.rollback()
        raise
    finally:
        db.close()


def update_rental_status(role: str, rental_id: int, new_status: str) -> Dict[str, Any]:
    """Обновить статус аренды (должно логироваться триггером)"""
    db = get_session_for_role(role)
    try:
        rental = db.query(Rental).filter(Rental.id == rental_id).first()
        if not rental:
            raise ValueError(f"Аренда с ID {rental_id} не найдена")
        
        rental.status = RentalStatus(new_status)
        db.commit()
        db.refresh(rental)
        
        return {
            "id": rental.id,
            "status": rental.status.value
        }
    except Exception as e:
        db.rollback()
        raise
    finally:
        db.close()


# ========== MOVEMENTS (Перемещения) ==========

def get_movements_list(role: str) -> List[Dict[str, Any]]:
    """Получить список перемещений"""
    db = get_session_for_role(role)
    try:
        movements_list = db.query(Movement).all()
        return [
            {
                "id": m.id,
                "equipment_id": m.equipment_id,
                "from_location_id": m.from_location_id,
                "to_location_id": m.to_location_id,
                "logistic_id": m.logistic_id,
                "movement_date": str(m.movement_date),
                "notes": m.notes
            }
            for m in movements_list
        ]
    finally:
        db.close()


def create_movement(role: str, equipment_id: int, to_location_id: int,
                    logistic_id: int, from_location_id: Optional[int] = None,
                    notes: Optional[str] = None) -> Dict[str, Any]:
    """Создать перемещение (должно логироваться триггером)"""
    db = get_session_for_role(role)
    try:
        new_movement = Movement(
            equipment_id=equipment_id,
            from_location_id=from_location_id,
            to_location_id=to_location_id,
            logistic_id=logistic_id,
            notes=notes
        )
        db.add(new_movement)
        db.commit()
        db.refresh(new_movement)
        
        return {
            "id": new_movement.id,
            "equipment_id": new_movement.equipment_id,
            "to_location_id": new_movement.to_location_id
        }
    except Exception as e:
        db.rollback()
        raise
    finally:
        db.close()


# ========== SERVICE LOGS (ТО и ремонты) ==========

def get_service_logs_list(role: str) -> List[Dict[str, Any]]:
    """Получить список ТО/ремонтов"""
    db = get_session_for_role(role)
    try:
        logs_list = db.query(ServiceLog).all()
        return [
            {
                "id": sl.id,
                "equipment_id": sl.equipment_id,
                "mechanic_id": sl.mechanic_id,
                "service_type": sl.service_type.value if sl.service_type else None,
                "description": sl.description,
                "start_date": str(sl.start_date),
                "end_date": str(sl.end_date) if sl.end_date else None,
                "cost": float(sl.cost) if sl.cost else None
            }
            for sl in logs_list
        ]
    finally:
        db.close()


def create_service_log(role: str, equipment_id: int, mechanic_id: int,
                       service_type: str, description: Optional[str] = None,
                       cost: Optional[float] = None) -> Dict[str, Any]:
    """Создать запись ТО/ремонта (должно логироваться триггером)"""
    db = get_session_for_role(role)
    try:
        new_log = ServiceLog(
            equipment_id=equipment_id,
            mechanic_id=mechanic_id,
            service_type=ServiceType(service_type),
            description=description,
            cost=cost
        )
        db.add(new_log)
        db.commit()
        db.refresh(new_log)
        
        return {
            "id": new_log.id,
            "equipment_id": new_log.equipment_id,
            "service_type": new_log.service_type.value
        }
    except Exception as e:
        db.rollback()
        raise
    finally:
        db.close()


def close_service_log(role: str, service_log_id: int, cost: Optional[float] = None) -> Dict[str, Any]:
    """Закрыть ТО/ремонт (должно логироваться триггером)"""
    db = get_session_for_role(role)
    try:
        service_log = db.query(ServiceLog).filter(ServiceLog.id == service_log_id).first()
        if not service_log:
            raise ValueError(f"Запись ТО с ID {service_log_id} не найдена")
        
        service_log.end_date = datetime.utcnow()
        if cost:
            service_log.cost = cost
        db.commit()
        db.refresh(service_log)
        
        return {
            "id": service_log.id,
            "end_date": str(service_log.end_date)
        }
    except Exception as e:
        db.rollback()
        raise
    finally:
        db.close()


# ========== LOGS (Таблица логов) ==========

def get_logs_list(role: str, limit: int = 50) -> List[Dict[str, Any]]:
    """Получить последние записи из таблицы logs (логирование действий)"""
    db = get_session_for_role(role)
    try:
        logs_list = db.query(Log).order_by(Log.created_at.desc()).limit(limit).all()
        return [
            {
                "id": log.id,
                "action": log.action,
                "table_name": log.table_name,
                "record_id": log.record_id,
                "user_id": log.user_id,
                "details": log.details,
                "created_at": str(log.created_at)
            }
            for log in logs_list
        ]
    finally:
        db.close()


# ========== LOCATIONS (Локации) ==========

def get_locations_list(role: str) -> List[Dict[str, Any]]:
    """Получить список локаций"""
    db = get_session_for_role(role)
    try:
        locations_list = db.query(Location).all()
        return [
            {
                "id": loc.id,
                "name": loc.name,
                "address": loc.address,
                "location_type": loc.location_type.value if loc.location_type else None
            }
            for loc in locations_list
        ]
    finally:
        db.close()


# ========== COUNTERPARTIES (Контрагенты) ==========

def get_counterparties_list(role: str) -> List[Dict[str, Any]]:
    """Получить список контрагентов"""
    db = get_session_for_role(role)
    try:
        counterparties_list = db.query(Counterparty).all()
        return [
            {
                "id": cp.id,
                "name": cp.name,
                "contact_person": cp.contact_person,
                "phone": cp.phone,
                "email": cp.email
            }
            for cp in counterparties_list
        ]
    finally:
        db.close()

