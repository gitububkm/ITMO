"""
SQLAlchemy модели для всех таблиц БД
Соответствуют структуре БД из ЛР2
"""
from sqlalchemy import (
    Column, Integer, String, Text, Date, DateTime, 
    Numeric, ForeignKey, Boolean, Enum as SQLEnum
)
from sqlalchemy.orm import relationship
from db.database import Base
from datetime import datetime
import enum


# ENUM типы (соответствуют созданным в PostgreSQL)
class EquipmentStatus(enum.Enum):
    """Статус техники"""
    available = "available"  # Доступна
    rented = "rented"  # В аренде
    maintenance = "maintenance"  # На ТО/ремонте
    unavailable = "unavailable"  # Недоступна


class LocationType(enum.Enum):
    """Тип локации"""
    hub = "hub"  # Хаб
    warehouse = "warehouse"  # Склад
    site = "site"  # Объект


class RentalStatus(enum.Enum):
    """Статус аренды"""
    active = "active"  # Активна
    completed = "completed"  # Завершена
    cancelled = "cancelled"  # Отменена


class ServiceType(enum.Enum):
    """Тип обслуживания"""
    maintenance = "maintenance"  # ТО
    repair = "repair"  # Ремонт


class WorkStatus(enum.Enum):
    """Статус работы"""
    scheduled = "scheduled"  # Запланирована
    in_progress = "in_progress"  # В процессе
    completed = "completed"  # Завершена
    cancelled = "cancelled"  # Отменена


class LogAction(enum.Enum):
    """Действия для логирования"""
    user_registered = "user_registered"
    equipment_registered = "equipment_registered"
    service_opened = "service_opened"
    service_closed = "service_closed"
    work_status_changed = "work_status_changed"
    movement_created = "movement_created"
    rental_created = "rental_created"
    rental_status_changed = "rental_status_changed"


# ========== Основные таблицы ==========

class User(Base):
    """Пользователи системы"""
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(100), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=True)
    full_name = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    # Связи
    service_logs = relationship("ServiceLog", back_populates="mechanic")
    movements = relationship("Movement", back_populates="logistic")


class Equipment(Base):
    """Строительная техника"""
    __tablename__ = "equipment"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    model = Column(String(100), nullable=True)
    serial_number = Column(String(100), unique=True, nullable=True, index=True)
    status = Column(SQLEnum(EquipmentStatus), nullable=False, default=EquipmentStatus.available)
    current_location_id = Column(Integer, ForeignKey("locations.id"), nullable=True)
    purchase_date = Column(Date, nullable=True)
    price = Column(Numeric(12, 2), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    # Связи
    current_location = relationship("Location", foreign_keys=[current_location_id])
    rentals = relationship("Rental", back_populates="equipment")
    service_logs = relationship("ServiceLog", back_populates="equipment")
    movements = relationship("Movement", back_populates="equipment")


class Location(Base):
    """Локации (хабы, склады, объекты)"""
    __tablename__ = "locations"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    address = Column(Text, nullable=True)
    location_type = Column(SQLEnum(LocationType), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    # Связи
    equipment_at_location = relationship("Equipment", foreign_keys=[Equipment.current_location_id])
    movements_from = relationship("Movement", foreign_keys="Movement.from_location_id", back_populates="from_location")
    movements_to = relationship("Movement", foreign_keys="Movement.to_location_id", back_populates="to_location")


class Counterparty(Base):
    """Контрагенты (арендаторы, подрядчики)"""
    __tablename__ = "counterparties"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    contact_person = Column(String(255), nullable=True)
    phone = Column(String(50), nullable=True)
    email = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    # Связи
    rentals = relationship("Rental", back_populates="counterparty")


class Rental(Base):
    """Аренда техники"""
    __tablename__ = "rentals"
    
    id = Column(Integer, primary_key=True, index=True)
    equipment_id = Column(Integer, ForeignKey("equipment.id"), nullable=False)
    counterparty_id = Column(Integer, ForeignKey("counterparties.id"), nullable=False)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=True)
    daily_rate = Column(Numeric(10, 2), nullable=False)
    status = Column(SQLEnum(RentalStatus), nullable=False, default=RentalStatus.active)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    # Связи
    equipment = relationship("Equipment", back_populates="rentals")
    counterparty = relationship("Counterparty", back_populates="rentals")


class ServiceLog(Base):
    """ТО и ремонты"""
    __tablename__ = "service_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    equipment_id = Column(Integer, ForeignKey("equipment.id"), nullable=False)
    mechanic_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    service_type = Column(SQLEnum(ServiceType), nullable=False)
    description = Column(Text, nullable=True)
    start_date = Column(DateTime, nullable=False)
    end_date = Column(DateTime, nullable=True)
    cost = Column(Numeric(10, 2), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    # Связи
    equipment = relationship("Equipment", back_populates="service_logs")
    mechanic = relationship("User", back_populates="service_logs")
    works = relationship("Work", back_populates="service_log")


class Work(Base):
    """Статусы работ"""
    __tablename__ = "works"
    
    id = Column(Integer, primary_key=True, index=True)
    service_log_id = Column(Integer, ForeignKey("service_logs.id"), nullable=False)
    work_status = Column(SQLEnum(WorkStatus), nullable=False, default=WorkStatus.scheduled)
    changed_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    # Связи
    service_log = relationship("ServiceLog", back_populates="works")


class Movement(Base):
    """Перемещения техники"""
    __tablename__ = "movements"
    
    id = Column(Integer, primary_key=True, index=True)
    equipment_id = Column(Integer, ForeignKey("equipment.id"), nullable=False)
    from_location_id = Column(Integer, ForeignKey("locations.id"), nullable=True)
    to_location_id = Column(Integer, ForeignKey("locations.id"), nullable=False)
    logistic_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    movement_date = Column(DateTime, nullable=False, default=datetime.utcnow)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    # Связи
    equipment = relationship("Equipment", back_populates="movements")
    from_location = relationship("Location", foreign_keys=[from_location_id], back_populates="movements_from")
    to_location = relationship("Location", foreign_keys=[to_location_id], back_populates="movements_to")
    logistic = relationship("User", back_populates="movements")


class Statistics(Base):
    """Статистика за периоды"""
    __tablename__ = "statistics"
    
    id = Column(Integer, primary_key=True, index=True)
    period_start = Column(Date, nullable=False)
    period_end = Column(Date, nullable=False)
    total_equipment = Column(Integer, nullable=False, default=0)
    rented_equipment = Column(Integer, nullable=False, default=0)
    maintenance_equipment = Column(Integer, nullable=False, default=0)
    total_revenue = Column(Numeric(12, 2), nullable=False, default=0)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)


class Log(Base):
    """Логи действий (заполняется триггерами)"""
    __tablename__ = "logs"
    
    id = Column(Integer, primary_key=True, index=True)
    action = Column(String(100), nullable=False, index=True)
    table_name = Column(String(100), nullable=True)
    record_id = Column(Integer, nullable=True)
    user_id = Column(Integer, nullable=True)
    details = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)

