"""
Модели для пользователей приложения
Отдельно от пользователей БД (users)
"""
import enum
from sqlalchemy import Column, Integer, String, Enum as SQLEnum
from sqlalchemy.orm import relationship
from flask_login import UserMixin
from db.database import Base


class AppRole(enum.Enum):
    """Роли пользователей приложения"""
    mechanic = "mechanic"  # Механик
    logistic = "logistic"  # Логист
    rental_manager = "rental_manager"  # Менеджер аренды
    admin = "admin"  # Администратор


class AppUser(Base, UserMixin):
    """Пользователи приложения (для Flask-Login)"""
    __tablename__ = "app_users"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(100), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=True)
    password_hash = Column(String(255), nullable=False)
    role = Column(SQLEnum(AppRole), nullable=False)
    is_active = Column(String(10), default="true", nullable=False)
    
    def get_role(self) -> str:
        """Возвращает роль как строку"""
        return self.role.value
    
    def __repr__(self):
        return f"<AppUser {self.username} ({self.role.value})>"

