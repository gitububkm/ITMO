"""
Скрипт для инициализации пользователей приложения
Создаёт тестовых пользователей для каждой роли
"""
from models.app_models import AppUser, AppRole
from db.database import get_session, get_engine, Base
from auth.security import hash_password

def init_users():
    """Создать тестовых пользователей приложения"""
    print("Инициализация пользователей приложения...")
    
    # Создать таблицу app_users
    engine = get_engine("root")
    Base.metadata.create_all(bind=engine)
    print("✅ Таблица app_users создана (если не существовала)")
    
    # Тестовые пользователи
    test_users = [
        {
            "username": "mechanic1",
            "email": "mechanic1@example.com",
            "password": "mechanic_pass",
            "role": AppRole.mechanic
        },
        {
            "username": "logistic1",
            "email": "logistic1@example.com",
            "password": "logistic_pass",
            "role": AppRole.logistic
        },
        {
            "username": "rental_manager1",
            "email": "rental1@example.com",
            "password": "rental_pass",
            "role": AppRole.rental_manager
        },
        {
            "username": "admin1",
            "email": "admin1@example.com",
            "password": "admin_pass",
            "role": AppRole.admin
        }
    ]
    
    db = get_session("root")
    try:
        created_count = 0
        skipped_count = 0
        
        for user_data in test_users:
            # Проверка существования
            existing = db.query(AppUser).filter(AppUser.username == user_data["username"]).first()
            
            if existing:
                print(f"⚠️  Пользователь '{user_data['username']}' уже существует - пропуск")
                skipped_count += 1
                continue
            
            # Создание пользователя
            new_user = AppUser(
                username=user_data["username"],
                email=user_data["email"],
                password_hash=hash_password(user_data["password"]),
                role=user_data["role"]
            )
            db.add(new_user)
            created_count += 1
            print(f"✅ Создан пользователь: {user_data['username']} ({user_data['role'].value})")
        
        db.commit()
        print(f"\n✅ Готово! Создано: {created_count}, пропущено: {skipped_count}")
        print("\n📋 Список пользователей:")
        print("   " + "-"*60)
        for user_data in test_users:
            print(f"   {user_data['username']:20s} / {user_data['password']:15s} ({user_data['role'].value})")
        print("   " + "-"*60)
        
    except Exception as e:
        db.rollback()
        print(f"❌ Ошибка создания пользователей: {str(e)}")
        raise
    finally:
        db.close()


if __name__ == "__main__":
    init_users()

