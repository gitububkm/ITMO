"""
Аутентификация и авторизация пользователей приложения
Flask-Login + bcrypt
"""
from flask_login import LoginManager, login_user, logout_user, current_user
from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from models.app_models import AppUser, AppRole
from auth.security import hash_password, verify_password
from db.database import get_session
from functools import wraps

login_manager = LoginManager()

# Blueprint для маршрутов авторизации
auth_bp = Blueprint('auth', __name__, url_prefix='/auth')


@login_manager.user_loader
def load_user(user_id):
    """Загрузка пользователя для Flask-Login"""
    db = get_session("root")  # Используем root для чтения app_users
    try:
        return db.query(AppUser).get(int(user_id))
    finally:
        db.close()


@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    """Регистрация нового пользователя"""
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        role_str = request.form.get('role')
        
        if not username or not password or not role_str:
            flash('Все поля обязательны для заполнения', 'error')
            return render_template('register.html')
        
        try:
            role = AppRole(role_str)
        except ValueError:
            flash('Некорректная роль', 'error')
            return render_template('register.html')
        
        db = get_session("root")
        try:
            # Проверка на существующего пользователя
            existing_user = db.query(AppUser).filter(
                (AppUser.username == username) | (AppUser.email == email)
            ).first()
            
            if existing_user:
                flash('Пользователь с таким именем или email уже существует', 'error')
                return render_template('register.html')
            
            # Создание нового пользователя
            new_user = AppUser(
                username=username,
                email=email,
                password_hash=hash_password(password),
                role=role
            )
            db.add(new_user)
            db.commit()
            
            flash('Регистрация успешна! Войдите в систему.', 'success')
            return redirect(url_for('auth.login'))
        except Exception as e:
            db.rollback()
            flash(f'Ошибка регистрации: {str(e)}', 'error')
        finally:
            db.close()
    
    return render_template('register.html')


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """Вход в систему"""
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if not username or not password:
            flash('Введите имя пользователя и пароль', 'error')
            return render_template('login.html')
        
        db = get_session("root")
        try:
            user = db.query(AppUser).filter(AppUser.username == username).first()
            
            if user and verify_password(password, user.password_hash):
                login_user(user, remember=True)
                flash(f'Добро пожаловать, {user.username}!', 'success')
                return redirect(url_for('main.home'))
            else:
                flash('Неверное имя пользователя или пароль', 'error')
        finally:
            db.close()
    
    return render_template('login.html')


@auth_bp.route('/logout')
def logout():
    """Выход из системы"""
    logout_user()
    flash('Вы вышли из системы', 'info')
    return redirect(url_for('main.home'))


def role_required(*allowed_roles):
    """
    Декоратор для проверки роли пользователя
    
    Args:
        *allowed_roles: разрешённые роли (AppRole)
    
    Example:
        @role_required(AppRole.admin, AppRole.rental_manager)
        def admin_page():
            ...
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                return abort(401)
            
            user_role = current_user.role
            if user_role not in allowed_roles:
                return abort(403)
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def get_db_role_for_user():
    """
    Получить роль PostgreSQL для текущего пользователя приложения
    
    Returns:
        строка с ролью PostgreSQL (mechanic, logistic, rental_manager, admin)
    """
    if not current_user.is_authenticated:
        return "root"  # По умолчанию
    
    role_mapping = {
        AppRole.mechanic: "mechanic",
        AppRole.logistic: "logistic",
        AppRole.rental_manager: "rental_manager",
        AppRole.admin: "admin"
    }
    
    return role_mapping.get(current_user.role, "root")

