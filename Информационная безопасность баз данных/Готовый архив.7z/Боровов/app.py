"""
Главное приложение Flask
Веб-сервис для работы с БД строительной техники
"""
import os
from flask import Flask, render_template, request, redirect, url_for, flash, abort, jsonify
from flask_login import current_user, login_required
from auth.auth import auth_bp, login_manager, role_required, get_db_role_for_user
from auth.security import verify_password, hash_password
from models.app_models import AppUser, AppRole
from models.db_models import Base
from db.database import get_session, get_engine
from utils.crud import (
    get_equipment_list, create_equipment, update_equipment_status,
    get_rentals_list, create_rental, update_rental_status,
    get_movements_list, create_movement,
    get_service_logs_list, create_service_log, close_service_log,
    get_logs_list, get_locations_list, get_counterparties_list,
    PermissionDeniedError, execute_with_role_check
)
from datetime import datetime, date
import config

app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", config.settings.SECRET_KEY)

# Flask-Login
login_manager.init_app(app)
login_manager.login_view = 'auth.login'
login_manager.login_message = 'Пожалуйста, войдите в систему для доступа к этой странице.'

# Регистрация Blueprint
app.register_blueprint(auth_bp)

# Создание таблицы app_users при запуске приложения
def create_tables():
    """Создать таблицу app_users в БД"""
    try:
        engine = get_engine("root")
        Base.metadata.create_all(bind=engine)
        print("✅ Таблица app_users создана (если не существовала)")
    except Exception as e:
        print(f"⚠️  Ошибка создания таблицы app_users: {str(e)}")

# Создаём таблицы при запуске
create_tables()


# ========== Страницы ошибок ==========

@app.errorhandler(401)
def err_401(error):
    """Ошибка 401 - не авторизован"""
    return render_template('errors/401.html'), 401


@app.errorhandler(403)
def err_403(error):
    """Ошибка 403 - доступ запрещён"""
    return render_template('errors/403.html'), 403


@app.errorhandler(500)
def err_500(error):
    """Ошибка 500 - внутренняя ошибка сервера"""
    return render_template('errors/500.html', error=str(error)), 500


# ========== Главная страница ==========

@app.route('/')
def home():
    """Главная страница"""
    return render_template('home.html')


# ========== Оборудование (Equipment) ==========

@app.route('/equipment')
@login_required
def equipment_list():
    """Список оборудования"""
    role = get_db_role_for_user()
    
    try:
        equipment = execute_with_role_check(role, "Просмотр оборудования", get_equipment_list, role)
        
        # Проверяем, можем ли мы создавать/изменять
        can_edit = current_user.role in [AppRole.admin, AppRole.rental_manager]
        
        return render_template('tables/equipment.html', 
                             equipment=equipment, 
                             can_edit=can_edit,
                             current_role=current_user.role.value)
    except PermissionDeniedError as e:
        flash(f'Ошибка доступа: {str(e)}', 'error')
        return abort(403)
    except Exception as e:
        flash(f'Ошибка: {str(e)}', 'error')
        return render_template('tables/equipment.html', equipment=[], can_edit=False)


@app.route('/equipment/create', methods=['POST'])
@login_required
@role_required(AppRole.admin, AppRole.rental_manager)
def equipment_create():
    """Создать новое оборудование"""
    role = get_db_role_for_user()
    
    try:
        name = request.form.get('name')
        model = request.form.get('model')
        serial_number = request.form.get('serial_number')
        location_id = request.form.get('location_id', type=int)
        
        if not name:
            flash('Название оборудования обязательно', 'error')
            return redirect(url_for('equipment_list'))
        
        new_equipment = execute_with_role_check(
            role, "Создание оборудования", create_equipment,
            role, name, model, serial_number, location_id
        )
        
        flash(f'Оборудование "{new_equipment["name"]}" успешно создано', 'success')
        flash('Действие залогировано в таблицу logs', 'info')
    except PermissionDeniedError as e:
        flash(f'Ошибка доступа: {str(e)}', 'error')
    except Exception as e:
        flash(f'Ошибка создания: {str(e)}', 'error')
    
    return redirect(url_for('equipment_list'))


@app.route('/equipment/<int:equipment_id>/update_status', methods=['POST'])
@login_required
@role_required(AppRole.admin, AppRole.rental_manager)
def equipment_update_status(equipment_id):
    """Обновить статус оборудования"""
    role = get_db_role_for_user()
    
    try:
        new_status = request.form.get('status')
        if not new_status:
            flash('Статус не указан', 'error')
            return redirect(url_for('equipment_list'))
        
        updated = execute_with_role_check(
            role, "Обновление статуса оборудования", update_equipment_status,
            role, equipment_id, new_status
        )
        
        flash(f'Статус оборудования обновлён на "{new_status}"', 'success')
        flash('Действие залогировано в таблицу logs', 'info')
    except PermissionDeniedError as e:
        flash(f'Ошибка доступа: {str(e)}', 'error')
    except Exception as e:
        flash(f'Ошибка обновления: {str(e)}', 'error')
    
    return redirect(url_for('equipment_list'))


# ========== Аренда (Rentals) ==========

@app.route('/rentals')
@login_required
def rentals_list():
    """Список аренды"""
    role = get_db_role_for_user()
    
    try:
        rentals = execute_with_role_check(role, "Просмотр аренды", get_rentals_list, role)
        
        # Только rental_manager и admin могут видеть аренду
        can_edit = current_user.role in [AppRole.admin, AppRole.rental_manager]
        
        return render_template('tables/rentals.html', 
                             rentals=rentals, 
                             can_edit=can_edit,
                             current_role=current_user.role.value)
    except PermissionDeniedError as e:
        flash(f'Ошибка доступа: {str(e)}', 'error')
        return abort(403)
    except Exception as e:
        flash(f'Ошибка: {str(e)}', 'error')
        return render_template('tables/rentals.html', rentals=[], can_edit=False)


@app.route('/rentals/create', methods=['POST'])
@login_required
@role_required(AppRole.admin, AppRole.rental_manager)
def rentals_create():
    """Создать новую аренду"""
    role = get_db_role_for_user()
    
    try:
        equipment_id = request.form.get('equipment_id', type=int)
        counterparty_id = request.form.get('counterparty_id', type=int)
        start_date_str = request.form.get('start_date')
        daily_rate = request.form.get('daily_rate', type=float)
        
        if not all([equipment_id, counterparty_id, start_date_str, daily_rate]):
            flash('Все поля обязательны', 'error')
            return redirect(url_for('rentals_list'))
        
        start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
        
        new_rental = execute_with_role_check(
            role, "Создание аренды", create_rental,
            role, equipment_id, counterparty_id, start_date, daily_rate
        )
        
        flash('Аренда успешно создана', 'success')
        flash('Действие залогировано в таблицу logs', 'info')
    except PermissionDeniedError as e:
        flash(f'Ошибка доступа: {str(e)}', 'error')
    except Exception as e:
        flash(f'Ошибка создания: {str(e)}', 'error')
    
    return redirect(url_for('rentals_list'))


# ========== Перемещения (Movements) ==========

@app.route('/movements')
@login_required
def movements_list():
    """Список перемещений"""
    role = get_db_role_for_user()
    
    try:
        movements = execute_with_role_check(role, "Просмотр перемещений", get_movements_list, role)
        
        # Только logistic и admin могут создавать перемещения
        can_edit = current_user.role in [AppRole.admin, AppRole.logistic]
        
        return render_template('tables/movements.html', 
                             movements=movements, 
                             can_edit=can_edit,
                             current_role=current_user.role.value)
    except PermissionDeniedError as e:
        flash(f'Ошибка доступа: {str(e)}', 'error')
        return abort(403)
    except Exception as e:
        flash(f'Ошибка: {str(e)}', 'error')
        return render_template('tables/movements.html', movements=[], can_edit=False)


# ========== ТО и ремонты (Service Logs) ==========

@app.route('/service_logs')
@login_required
def service_logs_list():
    """Список ТО и ремонтов"""
    role = get_db_role_for_user()
    
    try:
        logs = execute_with_role_check(role, "Просмотр ТО/ремонтов", get_service_logs_list, role)
        
        # Только mechanic и admin могут работать с ТО
        can_edit = current_user.role in [AppRole.admin, AppRole.mechanic]
        
        return render_template('tables/service_logs.html', 
                             logs=logs, 
                             can_edit=can_edit,
                             current_role=current_user.role.value)
    except PermissionDeniedError as e:
        flash(f'Ошибка доступа: {str(e)}', 'error')
        return abort(403)
    except Exception as e:
        flash(f'Ошибка: {str(e)}', 'error')
        return render_template('tables/service_logs.html', logs=[], can_edit=False)


# ========== Логи (Logs) ==========

@app.route('/logs')
@login_required
@role_required(AppRole.admin)
def logs_list():
    """Просмотр логов действий (только для администратора)"""
    role = get_db_role_for_user()
    
    try:
        logs = execute_with_role_check(role, "Просмотр логов", get_logs_list, role, limit=100)
        return render_template('tables/logs.html', logs=logs)
    except PermissionDeniedError as e:
        flash(f'Ошибка доступа: {str(e)}', 'error')
        return abort(403)
    except Exception as e:
        flash(f'Ошибка: {str(e)}', 'error')
        return render_template('tables/logs.html', logs=[])


# ========== API Endpoints (для демонстрации) ==========

@app.route('/api/demo/permission_test/<role>')
@login_required
@role_required(AppRole.admin)
def api_permission_test(role):
    """
    API endpoint для тестирования прав доступа разных ролей
    Демонстрирует ошибки permission denied
    """
    try:
        # Пытаемся получить список аренды от указанной роли
        rentals = execute_with_role_check(role, "Просмотр аренды", get_rentals_list, role)
        return jsonify({
            "success": True,
            "role": role,
            "message": f"Роль '{role}' имеет доступ к аренде",
            "count": len(rentals)
        })
    except PermissionDeniedError as e:
        return jsonify({
            "success": False,
            "role": role,
            "error": "Permission Denied",
            "message": str(e)
        }), 403
    except Exception as e:
        return jsonify({
            "success": False,
            "role": role,
            "error": str(e)
        }), 500


if __name__ == '__main__':
    app.run(host=config.settings.APP_HOST, 
            port=config.settings.APP_PORT, 
            debug=True)

